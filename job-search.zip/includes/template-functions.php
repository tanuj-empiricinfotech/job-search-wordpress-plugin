<?php
/**
 * Template Name: React Page Template
 */
get_header();


$current_user = wp_get_current_user();

if (!$current_user->user_email): 
  ?>
    <div class="container">
      <p>Need to <a href="<?php echo site_url('login-3'); ?>">login</a> before you can access this page</p>
    </div>
  <?php
else :
$authUser = ['email'=> $current_user->user_email, 'id' => get_current_user_id(), 'username'=> $current_user->user_login];
$ajax = ['url' => admin_url('admin-ajax.php'), 'site_url' => site_url(), 'nonce' => wp_create_nonce('job_search_nonce')];
echo "<script>const authUser = '".json_encode($authUser)."';const wpAjax = JSON.parse('".json_encode($ajax)."');</script>";
?>

<div id="react-page-template"></div>

<?php 
endif;
get_footer(); 
?>
